$(function() {
	// Tooltips are annoying
	// Use title attribute instead
	// $( 'input,textarea' ).tooltip();
});
